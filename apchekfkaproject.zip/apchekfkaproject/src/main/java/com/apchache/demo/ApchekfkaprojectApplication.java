package com.apchache.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApchekfkaprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApchekfkaprojectApplication.class, args);
	}

}
